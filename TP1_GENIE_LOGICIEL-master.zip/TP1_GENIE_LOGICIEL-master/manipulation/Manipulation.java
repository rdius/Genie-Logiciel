package com.all.manipulation;

public interface Manipulation {
	    boolean creer();
	    boolean editer(int id);
	    boolean supprimer(int id);
	    boolean ajouter(Object obj); 
}


