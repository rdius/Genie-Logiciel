/**
 * 
 */
/**
 * @author rdius
 *
 */
package com.all.entites;