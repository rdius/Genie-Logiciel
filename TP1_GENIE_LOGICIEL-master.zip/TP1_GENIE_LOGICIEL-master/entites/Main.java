package com.all.entites;

import com.all.manipulation.InterfaceUtilisateur;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceUtilisateur interfaceUtilisateur = new InterfaceUtilisateur();
		interfaceUtilisateur.execcutableProgramme();
		
		
	}

}
